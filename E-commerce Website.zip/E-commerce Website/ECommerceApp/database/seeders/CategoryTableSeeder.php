<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Category;

class CategoryTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Category::insert([
            [
            'id'=> '1',
            'category_name'=>'jewellary',
            'created_at'=> now(),
            'updated_at'=>now(),
            ],
            [
                'id'=> '2',
                'category_name'=>'electronic',
                'created_at'=> now(),
                'updated_at'=>now(),
            ],
            [
                'id'=> '3',
                'category_name'=>'fasion',
                'created_at'=> now(),
                'updated_at'=>now(),
                ]

        ]);
    }
}
