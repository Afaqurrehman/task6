<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Product;

class ProductTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Product::insert([
            [
                'id'=>'1',
                'category_id'=>'3',
                'product_name'=>'menteashirt',
                'description'=>'these shirts are very flexibale',
                'price'=>'200',
                'picture'=>'shirt1.jpg',
                'created_at'=>now(),
                'updated_at'=>now(),
            ],
            [
                'id'=>'2',
                'category_id'=>'3',
                'product_name'=>'menteashirt',
                'description'=>'these shirts are very flexibale',
                'price'=>'200',
                'picture'=>'shirt2.jpg',
                'created_at'=>now(),
                'updated_at'=>now(),
            ],
            [
                'id'=>'3',
                'category_id'=>'3',
                'product_name'=>'menteashirt',
                'description'=>'these shirts are very flexibale',
                'price'=>'200',
                'picture'=>'shirt3.jpg',
                'created_at'=>now(),
                'updated_at'=>now(),
            ],
            [
                'id'=>'4',
                'category_id'=>'2',
                'product_name'=>'microwaveoven',
                'description'=>'Home appliences',
                'price'=>'5000',
                'picture'=>'micro.jpg',
                'created_at'=>now(),
                'updated_at'=>now(),
            ],
            [
                'id'=>'5',
                'category_id'=>'2',
                'product_name'=>'refregirator',
                'description'=>'Home appliences',
                'price'=>'10000',
                'picture'=>'ref.jpg',
                'created_at'=>now(),
                'updated_at'=>now(),
            ],
            [
                'id'=>'6',
                'category_id'=>'2',
                'product_name'=>'iphone12',
                'description'=>'Available in All colours',
                'price'=>'10000',
                'picture'=>'ip12.jpg',
                'created_at'=>now(),
                'updated_at'=>now(),
            ],
            [
                'id'=>'7',
                'category_id'=>'1',
                'product_name'=>'Full nackless set',
                'description'=>'This is a full set',
                'price'=>'1000000',
                'picture'=>'nack.jpg',
                'created_at'=>now(),
                'updated_at'=>now(),
            ],
            [
                'id'=>'8',
                'category_id'=>'1',
                'product_name'=>'ring',
                'description'=>'Gold ring is here',
                'price'=>'1000000',
                'picture'=>'ring.jpg',
                'created_at'=>now(),
                'updated_at'=>now(),
            ],
            [
                'id'=>'9',
                'category_id'=>'1',
                'product_name'=>'braclet',
                'description'=>'pure gold braclet is here',
                'price'=>'1000000',
                'picture'=>'bra.jpg',
                'created_at'=>now(),
                'updated_at'=>now(),
            ]


        ]);
    }
}
