<?php

namespace App\Http\Controllers;
use App\Models\Category;
use App\Models\Product;

use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function addToCart(Request $request, $id)
    {
        $product = Product::find($id);

        if (!$product) {
            return redirect()->back()->with('error', 'Product not found');
        }

        // You can now add the product to the cart or save it in the database
        // For example, you can use Eloquent to save the product to another table
        // Assuming you have a Cart or Order model/table
        $order = new Order();
        $order->product_id = $product->id;
        $order->product_name = $product->name;
        $order->product_price = $product->price;
        $order->save();

        return redirect()->back()->with('success', 'Product added to cart');
    }
}
