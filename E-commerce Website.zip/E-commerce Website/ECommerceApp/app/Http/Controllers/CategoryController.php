<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Product;

class CategoryController extends Controller
{
    public function index(){


         $data = Product::join('categories', 'products.category_id', '=', 'categories.id')
        ->select('categories.category_name', 'products.product_name', 'products.price','products.picture','products.id')
        ->get();
        $organizedData = [];

foreach ($data as $product) {
    $category = $product["category_name"];

    if (!array_key_exists($category, $organizedData)) {
        $organizedData[$category] = [];
    }

    $productDetails = [
        "product_name" => $product["product_name"],
        "price" => $product["price"],
        "picture" => $product["picture"],
        "id" => $product["id"]
    ];

    $organizedData[$category][] = $productDetails;

}
    return view('index',["organizedData"=>  $organizedData]);


}

    public function electronic(){
        return view('categories.electronic');
    }

    public function fashion(){
        return view('categories.fashion');
    }

    public function jewellery(){
        return view('categories.jewellery');
    }


    public function addtocard($id){
        $data = Product::find($id);

    }


}
