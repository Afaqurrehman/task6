<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Category;
use App\Models\Product;

class CartController extends Controller
{
    public function add(Request $request, $product)
    {
        $data = Product::join('categories', 'products.category_id', '=', 'categories.id')
        ->select('categories.category_name', 'products.product_name', 'products.price', 'products.picture')
        ->get();

    $organizedData = [];

    foreach ($data as $product) {
        $category = $product->category_name;

        if (!array_key_exists($category, $organizedData)) {
            $organizedData[$category] = [];
        }

        $productDetails = [
            "product_name" => $product->product_name,
            "price" => $product->price,
            'picture' => $product->picture
        ];

        $organizedData[$category][] = $productDetails;
    }

    }

    public function show()
    {
        $cart = session()->get('cart', []);
        return view('add.show', compact('cart'));
    }
}
